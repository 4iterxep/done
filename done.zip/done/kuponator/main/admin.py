from django.contrib import admin

from .models import Kuponi, Basket

admin.site.register(Kuponi)
admin.site.register(Basket)